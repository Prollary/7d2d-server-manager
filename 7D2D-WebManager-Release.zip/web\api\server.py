import threading
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional

router = APIRouter()


@router.get("/status")
def get_status():
    """获取服务器运行状态"""
    from web.state import server_controller
    running = server_controller.is_running() if server_controller else False
    pid = server_controller.process.pid if running and server_controller.process else None
    return {"running": running, "pid": pid}

@router.post("/start")
def start_server():
    """启动服务器"""
    from web.state import server_controller, app_config
    if not server_controller:
        return {"success": False, "message": "服务未初始化"}
    if server_controller.is_running():
        return {"success": False, "message": "服务器已在运行中"}
    sc = app_config.get("server", {})
    if not sc.get("dir"):
        return {"success": False, "message": "未配置服务端目录，请先在【系统设置】中配置"}
    ok = server_controller.start_server()
    return {"success": ok, "message": "启动指令已发送" if ok else "启动失败，请检查服务端目录"}

@router.post("/stop")
def stop_server():
    """优雅停止服务器"""
    from web.state import server_controller
    if not server_controller or not server_controller.is_running():
        return {"success": False, "message": "服务器未在运行"}

    def _do():
        server_controller.stop_server()

    threading.Thread(target=_do, daemon=True).start()
    return {"success": True, "message": "关闭指令已发送，等待服务器退出（最多30秒）"}

@router.post("/force-stop")
def force_stop():
    """强制停止服务器"""
    from web.state import server_controller
    if not server_controller:
        return {"success": False, "message": "服务未初始化"}
    server_controller.force_stop()
    return {"success": True, "message": "已强制终止服务器进程"}

@router.post("/restart")
def restart_server():
    """重启服务器"""
    from web.state import server_controller
    if not server_controller:
        return {"success": False, "message": "服务未初始化"}

    def _do():
        server_controller.restart_server()

    threading.Thread(target=_do, daemon=True).start()
    return {"success": True, "message": "重启指令已发送"}

# ── 玩家管理 ──

@router.get("/players")
def get_players():
    """获取在线玩家列表"""
    from web.state import server_controller
    if not server_controller:
        raise HTTPException(503, "服务未初始化")
    if not server_controller.is_running():
        return {"players": [], "message": "服务器未运行"}
    try:
        players = server_controller.get_players()
        return {"players": players, "count": len(players)}
    except Exception as e:
        raise HTTPException(500, f"获取玩家列表失败：{e}")

class PlayerActionBody(BaseModel):
    player_id: str
    action: str  # kick | ban | admin | unadmin | unban
    reason: Optional[str] = ""
    duration: Optional[str] = "perm"

@router.post("/players/action")
def player_action(body: PlayerActionBody):
    """执行玩家管理操作"""
    from web.state import server_controller
    if not server_controller:
        raise HTTPException(503, "服务未初始化")
    if not server_controller.is_running() and body.action not in ("unban",):
        raise HTTPException(400, "服务器未在运行，无法执行玩家操作")

    ACTION_LABELS = {
        "kick": "踢出",
        "ban": "封禁",
        "admin": "设置管理员",
        "unadmin": "撤销管理员",
        "unban": "解除封禁",
    }
    if body.action not in ACTION_LABELS:
        raise HTTPException(400, f"未知操作类型: {body.action}")

    ok = server_controller.send_player_action(
        action=body.action,
        player_id=body.player_id,
        reason=body.reason or "",
        duration=body.duration or "perm",
    )
    label = ACTION_LABELS[body.action]
    if ok:
        return {"success": True, "message": f"玩家 {body.player_id} 已{label}"}
    else:
        raise HTTPException(500, f"操作失败，请确认 Telnet 已开启且密码正确（检查 serverconfig.xml 内 TelnetEnabled/TelnetPassword）")
