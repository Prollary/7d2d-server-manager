import os
import yaml
import json
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Dict

router = APIRouter()

CONFIG_FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "web_config.yaml")


def _cfg():
    from web.state import config_manager
    return config_manager


# ── serverconfig.xml 管理 ──

@router.get("/server")
def get_server_config():
    """获取 serverconfig.xml 的所有属性"""
    cfg = _cfg()
    if not cfg or cfg.root is None:
        raise HTTPException(400, "未加载 serverconfig.xml，请先在系统设置中配置路径")
    return {"properties": cfg.get_all_properties()}

@router.post("/server")
def save_server_config(body: Dict[str, str]):
    """保存 serverconfig.xml 属性"""
    cfg = _cfg()
    if not cfg or cfg.root is None:
        raise HTTPException(400, "未加载 serverconfig.xml")
    for key, value in body.items():
        cfg.set_value(key, value)
    if not cfg.save():
        raise HTTPException(500, "保存失败，请检查文件权限")
    return {"success": True, "message": "配置已保存"}

@router.post("/hanize")
def hanize_server_config():
    """配置文件汉化"""
    cfg = _cfg()
    if not cfg or cfg.root is None:
        raise HTTPException(400, "未加载 serverconfig.xml")
    
    i18n_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "core", "config_i18n.json")
    if not os.path.exists(i18n_path):
        raise HTTPException(500, "未找到汉化字典文件 config_i18n.json")
        
    try:
        with open(i18n_path, "r", encoding="utf-8") as f:
            mapping = json.load(f)
    except Exception as e:
        raise HTTPException(500, f"读取汉化字典失败：{e}")
        
    # 汉化前备份
    from web.state import app_config
    backup_dir = app_config.get("server", {}).get("backup_dir", "")
    if backup_dir:
        cfg.backup(backup_dir)
        
    if not cfg.hanize_config(mapping):
        raise HTTPException(500, "汉化过程失败，可能是由于文件权限或格式异常")
        
    return {"success": True, "message": "配置文件汉化成功！"}

# ── 路径 / Web 配置 ──

@router.get("/paths")
def get_paths():
    """获取系统路径配置"""
    from web.state import app_config
    sc = app_config.get("server", {})
    web = app_config.get("web", {})
    return {
        "server_dir":   sc.get("dir", ""),
        "config_path":  sc.get("config_path", ""),
        "backup_dir":   sc.get("backup_dir", ""),
        "saves_dir":    sc.get("saves_dir", ""),
        "web_host":     web.get("host", "0.0.0.0"),
        "web_port":     web.get("port", 8888),
    }

class PathsBody(BaseModel):
    server_dir:  str = ""
    config_path: str = ""
    backup_dir:  str = ""
    saves_dir:   str = ""
    web_host:    str = "0.0.0.0"
    web_port:    int = 8888

@router.post("/paths")
def save_paths(body: PathsBody):
    """保存系统路径配置"""
    from web.state import app_config, apply_paths
    app_config.setdefault("web", {})
    app_config["web"]["host"] = body.web_host
    app_config["web"]["port"] = body.web_port
    apply_paths(body.server_dir, body.config_path, body.backup_dir, body.saves_dir)
    # 持久化到 yaml
    try:
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            yaml.dump(app_config, f, allow_unicode=True, default_flow_style=False)
    except Exception as e:
        raise HTTPException(500, f"写入配置文件失败：{e}")
    return {"success": True, "message": "路径配置已保存，部分更改需重启Web服务生效"}

# ── 浏览服务端文件系统 ──
@router.get("/fs")
def browse_server_fs(path: str = "", type: str = "dir"):
    """浏览服务器文件/目录"""
    import os
    if not path and os.name == 'nt':
        import string
        drives = [{"name": f"{d}:\\", "path": f"{d}:\\"} for d in string.ascii_uppercase if os.path.exists(f"{d}:\\")]
        return {
            "current_path": "",
            "parent_path": None,
            "directories": drives,
            "files": []
        }
    
    if not path:
        path = "/" if os.name != 'nt' else "C:\\"

    if not os.path.exists(path) or not os.path.isdir(path):
        raise HTTPException(400, "路径不存在或不是目录")
    
    try:
        current_path = os.path.abspath(path)
        parent_path = os.path.dirname(current_path) if current_path != os.path.dirname(current_path) else None
        if os.name == 'nt' and current_path == parent_path:
            parent_path = "" 

        directories = []
        files = []
        for entry in os.scandir(current_path):
            try:
                if entry.is_dir():
                    directories.append({"name": entry.name, "path": entry.path})
                elif entry.is_file() and type == "file":
                    files.append({"name": entry.name, "path": entry.path})
            except Exception:
                pass 

        directories.sort(key=lambda x: x["name"].lower())
        files.sort(key=lambda x: x["name"].lower())

        return {
            "current_path": current_path,
            "parent_path": parent_path,
            "directories": directories,
            "files": files
        }
    except Exception as e:
        raise HTTPException(403, f"无权访问或出错: {e}")

