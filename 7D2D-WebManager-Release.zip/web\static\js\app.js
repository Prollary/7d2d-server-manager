const { createApp, ref, reactive, computed, onMounted, onUnmounted, nextTick } = Vue;

const api = axios.create({ baseURL: '/' });

createApp({
  setup() {
    // ── 导航 ──────────────────────────────────────────────────────────────────
    const page = ref('dashboard');
    const pages = [
      { id: 'dashboard', label: '服务器控制台', icon: '🖥' },
      { id: 'players', label: '玩家管理', icon: '👥' },
      { id: 'mods', label: '模组管理', icon: '🔧' },
      { id: 'worlds', label: '地图管理', icon: '🗺' },
      { id: 'settings', label: '服务器设置', icon: '⚙' },
      { id: 'tools', label: '辅助工具', icon: '🛠' },
      { id: 'sysconfig', label: '系统设置', icon: '🔩' },
    ];

    // ── Toast ─────────────────────────────────────────────────────────────────
    const toasts = ref([]);
    function toast(msg, type = 'info') {
      const id = Date.now();
      toasts.value.push({ id, msg, type });
      setTimeout(() => { toasts.value = toasts.value.filter(t => t.id !== id); }, 3500);
    }

    // ── 确认弹窗（使用浏览器原生对话框，保证 100% 可靠）──────────────────────
    function confirm(title, body) {
      return Promise.resolve(window.confirm(title + '\n\n' + body));
    }

    // ── 服务器状态 ────────────────────────────────────────────────────────────
    const serverRunning = ref(false);
    const serverPid = ref(null);
    const statusLoading = ref(false);

    async function fetchStatus() {
      try {
        const { data } = await api.get('/api/server/status');
        serverRunning.value = data.running;
        serverPid.value = data.pid;
      } catch { }
    }

    async function startServer() {
      statusLoading.value = true;
      try {
        const { data } = await api.post('/api/server/start');
        toast(data.message, data.success ? 'success' : 'error');
      } catch (e) {
        toast(e.response?.data?.detail || '请求失败', 'error');
      } finally {
        statusLoading.value = false;
        await fetchStatus();
      }
    }

    async function stopServer() {
      const ok = await confirm('停止服务器', '是否正常关闭服务器？若30秒内未响应，需要手动强制终止。');
      if (!ok) return;
      statusLoading.value = true;
      try {
        const { data } = await api.post('/api/server/stop');
        toast(data.message, data.success ? 'info' : 'error');
      } catch (e) {
        toast(e.response?.data?.detail || '请求失败', 'error');
      } finally { statusLoading.value = false; }
    }

    async function forceStop() {
      const ok = await confirm('强制终止', '⚠ 强制终止可能导致存档损坏！确认继续？');
      if (!ok) return;
      try {
        const { data } = await api.post('/api/server/force-stop');
        toast(data.message, 'info');
        await fetchStatus();
      } catch (e) {
        toast(e.response?.data?.detail || '请求失败', 'error');
      }
    }

    async function restartServer() {
      const ok = await confirm('重启服务器', '确认重启服务器吗？');
      if (!ok) return;
      try {
        const { data } = await api.post('/api/server/restart');
        toast(data.message, 'info');
      } catch (e) {
        toast(e.response?.data?.detail || '请求失败', 'error');
      }
    }

    // ── 日志 ─────────────────────────────────────────────────────────────────
    const logs = ref([]);
    const logEl = ref(null);
    let ws = null;

    function colorClass(line) {
      const l = line.toLowerCase();
      if (l.includes('err') || l.includes('exception') || l.includes('fatal')) return 'log-err';
      if (l.includes('wrn') || l.includes('warning')) return 'log-warn';
      if (l.includes('inf') || l.includes('player')) return 'log-info';
      if (l.includes('──')) return 'log-sys';
      return '';
    }

    let _heartbeat = null;
    function connectWS() {
      const proto = location.protocol === 'https:' ? 'wss' : 'ws';
      ws = new WebSocket(`${proto}://${location.host}/ws/logs`);
      ws.onopen = () => {
        console.log('[WS] 日志连接已建立');
        if (_heartbeat) clearInterval(_heartbeat);
        _heartbeat = setInterval(() => { if (ws && ws.readyState === 1) ws.send('ping'); }, 20000);
      };
      ws.onmessage = e => {
        logs.value.push(e.data);
        if (logs.value.length > 2000) logs.value.splice(0, 200);
        nextTick(() => { if (logEl.value) logEl.value.scrollTop = logEl.value.scrollHeight; });
      };
      ws.onerror = e => { console.log('[WS] 连接错误', e); };
      ws.onclose = () => {
        console.log('[WS] 连接关闭，2秒后重连...');
        if (_heartbeat) { clearInterval(_heartbeat); _heartbeat = null; }
        setTimeout(connectWS, 2000);
      };
    }
    function clearLogs() { logs.value = []; }

    // ── 玩家管理 ─────────────────────────────────────────────────────────────
    const players = ref([]);
    const playersLoading = ref(false);
    const ctxMenu = reactive({ show: false, x: 0, y: 0, player: null });

    async function fetchPlayers() {
      playersLoading.value = true;
      try {
        const { data } = await api.get('/api/server/players');
        players.value = data.players || [];
      } catch (e) {
        toast(e.response?.data?.detail || '获取玩家列表失败（确认Telnet已开启）', 'error');
      } finally { playersLoading.value = false; }
    }

    function showCtxMenu(event, player) {
      event.preventDefault();
      ctxMenu.show = true;
      ctxMenu.x = event.clientX;
      ctxMenu.y = event.clientY;
      ctxMenu.player = player;
    }

    function hideCtxMenu() { ctxMenu.show = false; }

    async function execPlayerAction(action) {
      hideCtxMenu();
      const p = ctxMenu.player;
      if (!p) return;

      const labels = { kick: '踢出', ban: '永久封禁', admin: '设为管理员', unadmin: '撤销管理员', unban: '解除封禁' };
      let reason = '', duration = 'perm';

      if (action === 'kick' || action === 'ban') {
        reason = window.prompt(`请输入对玩家 "${p.name}" 的${labels[action]}原因（可留空）:`) ?? '';
        if (reason === null) return;
      }
      if (action === 'ban') {
        const dur = window.prompt('封禁时长（如：60 minutes / 7 days / 1 year / perm）', 'perm');
        if (dur === null) return;
        duration = dur || 'perm';
      }

      const ok = await confirm(`确认${labels[action]}`, `确定要对玩家 "${p.name}" 执行【${labels[action]}】操作吗？`);
      if (!ok) return;

      try {
        const { data } = await api.post('/api/server/players/action', {
          player_id: p.id,
          action,
          reason,
          duration,
        });
        toast(data.message, 'success');
        if (action === 'kick' || action === 'ban') await fetchPlayers();
      } catch (e) {
        toast(e.response?.data?.detail || '操作失败', 'error');
      }
    }

    // ── 模组管理 ─────────────────────────────────────────────────────────────
    const mods = ref([]);

    async function fetchMods() {
      try {
        const { data } = await api.get('/api/mods');
        mods.value = data.mods;
      } catch (e) { toast(e.response?.data?.detail || '加载模组失败', 'error'); }
    }

    async function uploadMod(event) {
      const file = event.target.files[0];
      if (!file) return;
      const fd = new FormData();
      fd.append('file', file);
      try {
        const { data } = await api.post('/api/mods/upload', fd);
        toast(data.message, 'success');
        await fetchMods();
      } catch (e) { toast(e.response?.data?.detail || '上传失败', 'error'); }
      event.target.value = '';
    }

    async function toggleMod(raw) {
      try {
        await api.put(`/api/mods/${encodeURIComponent(raw)}/toggle`);
        await fetchMods();
      } catch (e) { toast(e.response?.data?.detail || '操作失败', 'error'); }
    }

    async function deleteMod(raw, name) {
      const ok = await confirm('删除模组', `确认删除模组 "${name}"？此操作不可撤销。`);
      if (!ok) return;
      try {
        await api.delete(`/api/mods/${encodeURIComponent(raw)}`);
        toast(`模组 "${name}" 已删除`, 'success');
        await fetchMods();
      } catch (e) { toast(e.response?.data?.detail || '删除失败', 'error'); }
    }

    // ── 地图管理 ─────────────────────────────────────────────────────────────
    const worlds = ref([]);
    const currentWorld = ref('');
    const selectedWorld = ref('');

    async function fetchWorlds() {
      try {
        const { data } = await api.get('/api/worlds');
        worlds.value = data.worlds;
        currentWorld.value = data.current;
        selectedWorld.value = data.current;
      } catch (e) { toast(e.response?.data?.detail || '加载地图失败', 'error'); }
    }

    async function uploadWorld(event) {
      const file = event.target.files[0];
      if (!file) return;
      const fd = new FormData();
      fd.append('file', file);
      try {
        const { data } = await api.post('/api/worlds/upload', fd);
        toast(data.message, 'success');
        await fetchWorlds();
      } catch (e) { toast(e.response?.data?.detail || '上传失败', 'error'); }
      event.target.value = '';
    }

    async function switchWorld() {
      if (!selectedWorld.value) return;
      try {
        const { data } = await api.put('/api/worlds/switch', { world_name: selectedWorld.value });
        toast(data.message, 'success');
        await fetchWorlds();
      } catch (e) { toast(e.response?.data?.detail || '切换失败', 'error'); }
    }

    async function deleteWorld(name) {
      const ok = await confirm('删除地图', `确认删除地图 "${name}"？`);
      if (!ok) return;
      try {
        await api.delete(`/api/worlds/${encodeURIComponent(name)}`);
        toast(`地图 "${name}" 已删除`, 'success');
        await fetchWorlds();
      } catch (e) { toast(e.response?.data?.detail || '删除失败', 'error'); }
    }

    // ── 服务器设置 + 配置汉化 ─────────────────────────────────────────────────
    const serverConfig = ref({});
    const hanizeLoading = ref(false);

    const FIELD_DEFS = [
      { key: 'ServerName', label: '服务器名称', type: 'text' },
      { key: 'ServerPassword', label: '服务器密码', type: 'text' },
      { key: 'ServerMaxPlayerCount', label: '最大玩家数', type: 'number', min: 1, max: 64 },
      {
        key: 'GameDifficulty', label: '游戏难度', type: 'select',
        options: ['0', '1', '2', '3', '4', '5'], labels: ['最简单', '简单', '普通', '困难', '非常困难', '最难']
      },
      {
        key: 'ZombieMove', label: '僵尸速度（白天）', type: 'select',
        options: ['0', '1', '2', '3'], labels: ['缓行', '慢跑', '奔跑', '冲刺']
      },
      {
        key: 'ZombieMoveNight', label: '僵尸速度（夜晚）', type: 'select',
        options: ['0', '1', '2', '3'], labels: ['缓行', '慢跑', '奔跑', '冲刺']
      },
      { key: 'BloodMoonFrequency', label: '血月频率（天）', type: 'number', min: 0, max: 99 },
      { key: 'BloodMoonEnemyCount', label: '血月僵尸数', type: 'number', min: 8, max: 128 },
      { key: 'XPMultiplier', label: '经验倍率（%）', type: 'number', min: 1, max: 500 },
      {
        key: 'DropOnDeath', label: '死亡掉落', type: 'select',
        options: ['0', '1', '2', '3'], labels: ['不掉落', '删除背包', '掉落所有', '掉落装备']
      },
      {
        key: 'DropOnQuit', label: '退出掉落', type: 'select',
        options: ['0', '1', '2', '3'], labels: ['不掉落', '删除背包', '掉落所有', '掉落装备']
      },
      {
        key: 'PlayerKillingMode', label: 'PVP 模式', type: 'select',
        options: ['0', '1', '2', '3'], labels: ['禁止PVP', '只能打非队友', '只能打非盟友', '可打任何人']
      },
      { key: 'AirDropFrequency', label: '空投频率（游戏时）', type: 'number', min: 0, max: 336 },
      { key: 'LandClaimSize', label: '领地石范围（格）', type: 'number', min: 1, max: 51 },
      { key: 'LootAbundance', label: '战利品丰富度（%）', type: 'number', min: 0, max: 500 },
      { key: 'LootRespawnDays', label: '战利品重置天数', type: 'number', min: 0, max: 999 },
      { key: 'BlockDamageAI', label: '僵尸破坏倍率（%）', type: 'number', min: 0, max: 500 },
      { key: 'TelnetEnabled', label: '启用 Telnet', type: 'bool' },
      { key: 'TelnetPort', label: 'Telnet 端口', type: 'number', min: 1, max: 65535 },
      { key: 'TelnetPassword', label: 'Telnet 密码', type: 'text' },
      { key: 'ServerPort', label: '服务器端口', type: 'number', min: 1, max: 65535 },
      { key: 'Region', label: '地区', type: 'text' },
      { key: 'Language', label: '语言', type: 'text' },
    ];

    async function fetchServerConfig() {
      try {
        const { data } = await api.get('/api/config/server');
        serverConfig.value = { ...data.properties };
      } catch (e) { toast(e.response?.data?.detail || '加载配置失败', 'error'); }
    }

    async function saveServerConfig() {
      try {
        const { data } = await api.post('/api/config/server', serverConfig.value);
        toast(data.message, 'success');
      } catch (e) { toast(e.response?.data?.detail || '保存失败', 'error'); }
    }

    async function hanizeConfig() {
      const ok = await confirm(
        '配置文件汉化',
        '将在 serverconfig.xml 中为每个配置项添加中文注释说明。\n操作前会自动备份原文件。确认继续？'
      );
      if (!ok) return;
      hanizeLoading.value = true;
      try {
        const { data } = await api.post('/api/config/hanize');
        toast(data.message, 'success');
      } catch (e) {
        toast(e.response?.data?.detail || '汉化失败，请检查配置文件路径', 'error');
      } finally { hanizeLoading.value = false; }
    }

    // ── 辅助工具 ─────────────────────────────────────────────────────────────
    const portResults = ref({});
    const fwResults = ref({});
    const backupResult = ref('');

    async function checkPorts() {
      try {
        const { data } = await api.get('/api/tools/network');
        portResults.value = data.ports;
      } catch { toast('端口检查失败', 'error'); }
    }

    async function openFirewall() {
      try {
        const { data } = await api.post('/api/tools/firewall');
        fwResults.value = data.results;
        toast('防火墙规则已处理', 'info');
      } catch { toast('操作失败（需管理员权限运行）', 'error'); }
    }

    async function doBackup() {
      try {
        const { data } = await api.post('/api/tools/backup');
        backupResult.value = data.path;
        toast(data.message, 'success');
      } catch (e) { toast(e.response?.data?.detail || '备份失败', 'error'); }
    }

    // ── 系统设置 ─────────────────────────────────────────────────────────────
    const sysPaths = reactive({
      server_dir: '', config_path: '', backup_dir: '',
      saves_dir: '', web_host: '0.0.0.0', web_port: 8888,
    });

    async function fetchSysPaths() {
      try {
        const { data } = await api.get('/api/config/paths');
        Object.assign(sysPaths, data);
      } catch { }
    }

    async function saveSysPaths() {
      try {
        const { data } = await api.post('/api/config/paths', sysPaths);
        toast(data.message, 'success');
      } catch (e) { toast(e.response?.data?.detail || '保存失败', 'error'); }
    }

    // ── 页面切换 ─────────────────────────────────────────────────────────────
    function switchPage(p) {
      page.value = p;
      hideCtxMenu();
      if (p === 'players') fetchPlayers();
      if (p === 'mods') fetchMods();
      if (p === 'worlds') fetchWorlds();
      if (p === 'settings') fetchServerConfig();
      if (p === 'sysconfig') fetchSysPaths();
    }

    // ── 生命周期 ─────────────────────────────────────────────────────────────
    let statusInterval, playersInterval;
    onMounted(() => {
      fetchStatus();
      connectWS();
      statusInterval = setInterval(fetchStatus, 3000);
      document.addEventListener('click', hideCtxMenu);
    });
    onUnmounted(() => {
      clearInterval(statusInterval);
      clearInterval(playersInterval);
      document.removeEventListener('click', hideCtxMenu);
      if (ws) ws.close();
    });

    return {
      page, pages, switchPage,
      toasts,
      serverRunning, serverPid, statusLoading,
      startServer, stopServer, forceStop, restartServer,
      logs, logEl, colorClass, clearLogs,
      players, playersLoading, ctxMenu, fetchPlayers, showCtxMenu, hideCtxMenu, execPlayerAction,
      mods, fetchMods, uploadMod, toggleMod, deleteMod,
      worlds, currentWorld, selectedWorld, fetchWorlds, uploadWorld, switchWorld, deleteWorld,
      serverConfig, FIELD_DEFS, fetchServerConfig, saveServerConfig,
      hanizeLoading, hanizeConfig,
      portResults, fwResults, backupResult, checkPorts, openFirewall, doBackup,
      sysPaths, fetchSysPaths, saveSysPaths,
    };
  },

  template: `
<div id="sidebar">
  <div class="sidebar-logo">⚙ 7D2D 管理器</div>
  <button v-for="p in pages" :key="p.id"
    class="nav-btn" :class="{active: page===p.id}"
    @click="switchPage(p.id)">
    {{ p.icon }}&nbsp; {{ p.label }}
  </button>
  <div class="sidebar-spacer"></div>
  <div class="sidebar-version">v1.0.0 · Web</div>
</div>

<div id="main" @click="hideCtxMenu">

  <!-- ── Dashboard ── -->
  <div v-if="page==='dashboard'" class="page">
    <div class="page-title">服务器控制台</div>
    <div class="status-bar">
      <div class="status-dot" :class="statusLoading?'loading':serverRunning?'on':'off'"></div>
      <span class="status-text">{{ statusLoading?'处理中…':serverRunning?'服务器运行中':'服务器已停止' }}</span>
      <span v-if="serverPid" style="color:var(--subtext);font-size:12px">PID: {{ serverPid }}</span>
      <div class="btn-row">
        <button class="btn btn-green"  :disabled="serverRunning||statusLoading"  @click="startServer">▶ 启动</button>
        <button class="btn btn-red"    :disabled="!serverRunning||statusLoading" @click="stopServer">■ 停止</button>
        <button class="btn btn-orange" :disabled="!serverRunning||statusLoading" @click="restartServer">↺ 重启</button>
        <button class="btn btn-ghost"  :disabled="!serverRunning" @click="forceStop" title="强制终止进程">⚡ 强制</button>
      </div>
    </div>
    <div class="card" style="flex:1;display:flex;flex-direction:column;gap:8px;">
      <div style="display:flex;align-items:center;justify-content:space-between;">
        <span class="card-title">实时日志</span>
        <button class="btn btn-ghost" style="padding:4px 10px;font-size:12px" @click="clearLogs">清空</button>
      </div>
      <div class="log-console" ref="logEl" style="flex:1;min-height:340px;height:auto;">
        <div v-for="(line,i) in logs" :key="i" :class="colorClass(line)">{{ line }}</div>
        <span v-if="logs.length===0" style="color:var(--muted)">等待服务器输出…</span>
      </div>
    </div>
  </div>

  <!-- ── 玩家管理 ── -->
  <div v-if="page==='players'" class="page">
    <div class="page-title">在线玩家管理</div>
    <div class="card">
      <div class="toolbar" style="margin-bottom:12px;">
        <button class="btn btn-blue" @click="fetchPlayers" :disabled="playersLoading">
          {{ playersLoading ? '加载中…' : '刷新列表' }}
        </button>
        <span style="color:var(--subtext);font-size:12px">
          在线 {{ players.length }} 人 &nbsp;·&nbsp; 右键玩家行进行管理操作
        </span>
      </div>
      <div v-if="!serverRunning" style="color:var(--orange);font-size:13px;padding:10px 0;">
        ⚠ 服务器未运行。启动服务器并确保已开启 Telnet（服务器设置中配置）后刷新。
      </div>
      <table v-else class="data-table" style="user-select:none;">
        <thead><tr>
          <th>#</th><th>玩家名</th><th>Entity ID</th><th>Steam ID</th><th>IP</th><th>延迟</th>
        </tr></thead>
        <tbody>
          <tr v-if="players.length===0 && !playersLoading">
            <td colspan="6" style="text-align:center;color:var(--subtext);padding:20px">暂无在线玩家</td>
          </tr>
          <tr v-for="(p,i) in players" :key="p.id"
            style="cursor:context-menu;"
            @contextmenu.prevent="showCtxMenu($event, p)">
            <td>{{ i+1 }}</td>
            <td><strong>{{ p.name }}</strong></td>
            <td style="font-family:monospace">{{ p.id }}</td>
            <td style="font-family:monospace;font-size:11px;color:var(--subtext)">{{ p.steam_id || '-' }}</td>
            <td>{{ p.ip || '-' }}</td>
            <td>
              <span :style="{color: p.ping>150?'var(--red)':p.ping>80?'var(--orange)':'var(--green)'}">
                {{ p.ping }} ms
              </span>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <div class="card" style="color:var(--subtext);font-size:12px;line-height:1.8;">
      <div class="card-title">使用说明</div>
      右键点击玩家行，可执行：<strong style="color:var(--text)">踢出、封禁、设为管理员、撤销管理员、解除封禁</strong><br>
      ⚠ 所有操作均通过 Telnet 发送至服务器，需在【服务器设置】中开启 <code style="color:var(--blue)">TelnetEnabled</code>
      并设置 <code style="color:var(--blue)">TelnetPassword</code>，然后在【系统设置】中填入对应密码。
    </div>
  </div>

  <!-- ── 模组管理 ── -->
  <div v-if="page==='mods'" class="page">
    <div class="page-title">模组管理</div>
    <div class="card">
      <div class="toolbar" style="margin-bottom:12px;">
        <label class="btn btn-blue" style="cursor:pointer;">
          + 安装 ZIP 模组
          <input type="file" accept=".zip" style="display:none" @change="uploadMod">
        </label>
        <button class="btn btn-ghost" @click="fetchMods">刷新</button>
        <span style="color:var(--subtext);font-size:12px">共 {{ mods.length }} 个模组</span>
      </div>
      <table class="data-table">
        <thead><tr><th>模组名称</th><th>状态</th><th>操作</th></tr></thead>
        <tbody>
          <tr v-if="mods.length===0">
            <td colspan="3" style="color:var(--subtext);text-align:center;padding:20px">暂无模组</td>
          </tr>
          <tr v-for="m in mods" :key="m.raw">
            <td>{{ m.name }}</td>
            <td><span class="badge" :class="m.enabled?'badge-green':'badge-red'">{{ m.enabled?'启用':'禁用' }}</span></td>
            <td>
              <div style="display:flex;gap:6px;">
                <button class="btn btn-ghost" style="padding:4px 10px;font-size:12px" @click="toggleMod(m.raw)">
                  {{ m.enabled?'禁用':'启用' }}
                </button>
                <button class="btn btn-red" style="padding:4px 10px;font-size:12px" @click="deleteMod(m.raw,m.name)">删除</button>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>

  <!-- ── 地图管理 ── -->
  <div v-if="page==='worlds'" class="page">
    <div class="page-title">地图管理</div>
    <div class="card">
      <div class="card-title">切换当前地图</div>
      <div style="display:flex;gap:10px;align-items:center;margin-bottom:16px;">
        <select v-model="selectedWorld" style="background:var(--overlay);border:1px solid var(--muted);border-radius:5px;padding:7px 10px;color:var(--text);font-size:13px;min-width:260px;">
          <option v-for="w in worlds" :key="w" :value="w">{{ w }}</option>
        </select>
        <button class="btn btn-blue" @click="switchWorld">应用</button>
        <span style="color:var(--subtext);font-size:12px">当前：{{ currentWorld||'未设置' }}</span>
      </div>
      <div class="toolbar" style="margin-bottom:14px;">
        <label class="btn btn-blue" style="cursor:pointer;">
          + 上传地图（ZIP）
          <input type="file" accept=".zip" style="display:none" @change="uploadWorld">
        </label>
        <button class="btn btn-ghost" @click="fetchWorlds">刷新</button>
      </div>
      <div class="world-list">
        <div v-for="w in worlds" :key="w" class="world-item" :class="{active:w===currentWorld}">
          <span class="world-name">{{ w }}</span>
          <span v-if="w===currentWorld" class="active-tag">✓ 当前</span>
          <button class="btn btn-red" style="padding:3px 10px;font-size:12px" @click="deleteWorld(w)">删除</button>
        </div>
        <div v-if="worlds.length===0" style="color:var(--subtext);padding:16px;text-align:center;">暂无地图</div>
      </div>
    </div>
  </div>

  <!-- ── 服务器设置 ── -->
  <div v-if="page==='settings'" class="page">
    <div class="page-title">服务器设置</div>

    <div class="card" style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;">
      <span style="color:var(--subtext);font-size:13px;flex:1;">
        一键汉化：在 serverconfig.xml 中为每个配置项插入中文注释，方便手动查阅编辑。
      </span>
      <button class="btn btn-orange" :disabled="hanizeLoading" @click="hanizeConfig">
        {{ hanizeLoading ? '汉化中…' : '📝 一键汉化配置文件' }}
      </button>
    </div>

    <div class="card">
      <div class="form-grid">
        <template v-for="f in FIELD_DEFS" :key="f.key">
          <div class="form-group">
            <label>{{ f.label }}</label>
            <input v-if="f.type==='text'||f.type==='number'"
                   :type="f.type" v-model="serverConfig[f.key]"
                   :min="f.min" :max="f.max" />
            <select v-else-if="f.type==='select'" v-model="serverConfig[f.key]">
              <option v-for="(o,i) in f.options" :key="o" :value="o">{{ f.labels[i] }}</option>
            </select>
            <div v-else-if="f.type==='bool'" style="display:flex;align-items:center;gap:8px;padding-top:4px;">
              <input type="checkbox"
                     :checked="serverConfig[f.key]==='true'"
                     @change="serverConfig[f.key]=$event.target.checked?'true':'false'" />
              <span style="color:var(--subtext);font-size:12px">{{ serverConfig[f.key]==='true'?'开启':'关闭' }}</span>
            </div>
          </div>
        </template>
      </div>
      <div style="margin-top:18px;display:flex;gap:8px;">
        <button class="btn btn-green" @click="saveServerConfig">保存配置</button>
        <button class="btn btn-ghost" @click="fetchServerConfig">重新加载</button>
      </div>
    </div>
  </div>

  <!-- ── 辅助工具 ── -->
  <div v-if="page==='tools'" class="page">
    <div class="page-title">辅助工具</div>
    <div class="card">
      <div class="card-title">网络诊断</div>
      <div class="toolbar" style="margin-bottom:12px;">
        <button class="btn btn-blue" @click="checkPorts">检查端口状态</button>
        <button class="btn btn-ghost" @click="openFirewall">一键开放防火墙（需管理员）</button>
      </div>
      <div v-if="Object.keys(portResults).length">
        <div v-for="(used,port) in portResults" :key="port" class="port-row">
          <span class="port-number">{{ port }}</span>
          <span class="port-status" :class="used?'port-bad':'port-ok'">{{ used?'⚠ 已被占用':'✓ 可用' }}</span>
        </div>
      </div>
      <div v-if="Object.keys(fwResults).length" style="margin-top:10px;">
        <div v-for="(ok,port) in fwResults" :key="port" class="port-row">
          <span class="port-number">{{ port }}</span>
          <span class="port-status" :class="ok?'port-ok':'port-bad'">{{ ok?'✓ 已开放':'✗ 失败' }}</span>
        </div>
      </div>
    </div>
    <div class="card">
      <div class="card-title">存档备份</div>
      <p style="color:var(--subtext);font-size:12px;margin-bottom:10px;">存档目录与备份目录在【系统设置】中配置。</p>
      <button class="btn btn-orange" @click="doBackup">立即备份存档</button>
      <div v-if="backupResult" style="margin-top:10px;color:var(--green);font-size:12px;">✓ 备份已保存：{{ backupResult }}</div>
    </div>
  </div>

  <!-- ── 系统设置 ── -->
  <div v-if="page==='sysconfig'" class="page">
    <div class="page-title">系统设置</div>
    <div class="card">
      <div class="card-title">路径配置</div>
      <div class="form-grid single">
        <div class="form-group">
          <label>7DaysToDie 服务端目录</label>
          <input type="text" v-model="sysPaths.server_dir" placeholder="例：C:/7DaysToDieServer" />
        </div>
        <div class="form-group">
          <label>serverconfig.xml 路径</label>
          <input type="text" v-model="sysPaths.config_path" placeholder="例：C:/7DaysToDieServer/serverconfig.xml" />
        </div>
        <div class="form-group">
          <label>存档目录（Saves）</label>
          <input type="text" v-model="sysPaths.saves_dir" placeholder="例：C:/7DaysToDieServer/Saves" />
        </div>
        <div class="form-group">
          <label>备份输出目录</label>
          <input type="text" v-model="sysPaths.backup_dir" placeholder="例：D:/Backups/7D2D" />
        </div>
      </div>
    </div>
    <div class="card">
      <div class="card-title">Web 服务端口</div>
      <div class="form-grid">
        <div class="form-group">
          <label>监听地址</label>
          <input type="text" v-model="sysPaths.web_host" placeholder="0.0.0.0" />
        </div>
        <div class="form-group">
          <label>监听端口</label>
          <input type="number" v-model="sysPaths.web_port" min="1024" max="65535" />
        </div>
      </div>
      <p style="color:var(--subtext);font-size:12px;margin-top:10px;">
        ⚠ 修改端口后需重启 Web 服务生效。外网访问请确保服务器防火墙已开放对应端口。
      </p>
    </div>
    <div style="display:flex;gap:8px;">
      <button class="btn btn-green" @click="saveSysPaths">保存设置</button>
      <button class="btn btn-ghost" @click="fetchSysPaths">重新加载</button>
    </div>
  </div>

</div><!-- #main -->

<!-- ── 右键菜单 ── -->
<div v-if="ctxMenu.show" class="ctx-menu"
  :style="{left: ctxMenu.x+'px', top: ctxMenu.y+'px'}"
  @click.stop>
  <div class="ctx-menu-header">{{ ctxMenu.player?.name }}</div>
  <button class="ctx-item" @click="execPlayerAction('kick')">🚫 踢出</button>
  <button class="ctx-item ctx-danger" @click="execPlayerAction('ban')">🔨 封禁</button>
  <div class="ctx-divider"></div>
  <button class="ctx-item" @click="execPlayerAction('admin')">⭐ 设为管理员</button>
  <button class="ctx-item" @click="execPlayerAction('unadmin')">✖ 撤销管理员</button>
  <div class="ctx-divider"></div>
  <button class="ctx-item" @click="execPlayerAction('unban')">✅ 解除封禁</button>
</div>

<!-- ── Toast ── -->
<div class="toast-container">
  <div v-for="t in toasts" :key="t.id" class="toast" :class="'toast-'+t.type">{{ t.msg }}</div>
</div>
  `,
}).mount('#app');
