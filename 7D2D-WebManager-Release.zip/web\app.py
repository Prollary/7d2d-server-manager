import sys
import os

# ── 确保项目根目录在 sys.path 中 ──
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)
os.chdir(ROOT)

import asyncio
import queue as sync_queue
import yaml
from contextlib import asynccontextmanager
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import uvicorn
from web.api import server as server_api
from web.api import mods as mods_api
from web.api import worlds as worlds_api
from web.api import config_api
from web.api import tools_api

# ── 生命周期 ──
@asynccontextmanager
async def lifespan(_app: FastAPI):
    _load_config()
    asyncio.create_task(_log_broadcaster())
    yield

# ── FastAPI 应用 ──
app = FastAPI(
    title="7D2D Server Manager",
    description="七日杀服务器 Web 管理面板",
    version="1.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    lifespan=lifespan,
)

app.include_router(server_api.router,  prefix="/api/server",  tags=["服务器控制"])
app.include_router(mods_api.router,    prefix="/api/mods",    tags=["模组管理"])
app.include_router(worlds_api.router,  prefix="/api/worlds",  tags=["地图管理"])
app.include_router(config_api.router,  prefix="/api/config",  tags=["配置管理"])
app.include_router(tools_api.router,   prefix="/api/tools",   tags=["辅助工具"])

STATIC_DIR = os.path.join(os.path.dirname(__file__), "static")
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

@app.get("/")
def index():
    return FileResponse(os.path.join(STATIC_DIR, "index.html"))

# ── WebSocket 日志广播 ──
_ws_clients: set[WebSocket] = set()

@app.websocket("/ws/logs")
async def ws_logs(websocket: WebSocket):
    await websocket.accept()
    
    # 发送历史日志给新连接的客户端
    from web.state import log_history
    for line in list(log_history):
        try:
            await websocket.send_text(line)
        except Exception:
            pass

    _ws_clients.add(websocket)
    try:
        while True:
            # 保持连接存活（客户端心跳）
            await websocket.receive_text()
    except (WebSocketDisconnect, Exception):
        _ws_clients.discard(websocket)

async def _log_broadcaster():
    """后台任务：将日志广播给所有连接的客户端"""
    from web.state import log_queue
    loop = asyncio.get_event_loop()
    while True:
        try:
            line = await loop.run_in_executor(None, _blocking_get, log_queue)
            dead = set()
            for ws in list(_ws_clients):
                try:
                    await ws.send_text(line)
                except Exception:
                    dead.add(ws)
            _ws_clients -= dead
        except Exception:
            await asyncio.sleep(0.05)

def _blocking_get(q: sync_queue.Queue, timeout: float = 0.05) -> str:
    try:
        return q.get(timeout=timeout)
    except sync_queue.Empty:
        raise

# ── 配置加载 ──
CONFIG_FILE = os.path.join(ROOT, "web_config.yaml")

def _load_config():
    from web.state import init_state
    config = {}
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            config = yaml.safe_load(f) or {}
    init_state(config)

# ── 程序入口 ──
def main():
    config = {}
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            config = yaml.safe_load(f) or {}
    web = config.get("web", {})
    host = web.get("host", "0.0.0.0")
    port = int(web.get("port", 8888))
    display_host = "127.0.0.1" if host == "0.0.0.0" else host
    print(f"[7D2D Manager] Web 面板启动中：http://{display_host}:{port}")
    print(f"[7D2D Manager] API 文档：http://{display_host}:{port}/api/docs")
    uvicorn.run("web.app:app", host=host, port=port, reload=False)

if __name__ == "__main__":
    main()
