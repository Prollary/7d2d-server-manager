import os
import queue as sync_queue
from collections import deque
from typing import Optional

# ── 日志广播 ──
log_queue: sync_queue.Queue = sync_queue.Queue(maxsize=2000)
log_history: deque = deque(maxlen=500)  # 保留最近 500 行日志记录
ws_clients: set = set()

# ── 全局单例 ──
from core.server import ServerController
from core.config import ConfigManager
from core.mod import ModManager, WorldManager

server_controller: Optional[ServerController] = None
config_manager: Optional[ConfigManager] = None
mod_manager: Optional[ModManager] = None
world_manager: Optional[WorldManager] = None
app_config: dict = {}

def _log_callback(text: str):
    """日志回调函数，将日志放入队列和历史记录"""
    log_history.append(text)
    try:
        log_queue.put_nowait(text)
    except sync_queue.Full:
        try:
            log_queue.get_nowait()
            log_queue.put_nowait(text)
        except Exception:
            pass

def init_state(config: dict):
    """初始化全局状态"""
    global server_controller, config_manager, mod_manager, world_manager, app_config
    app_config = config

    sc = config.get("server", {})
    server_dir = sc.get("dir", "")
    config_path = sc.get("config_path", "")

    config_manager = ConfigManager(config_path)
    if config_path and os.path.exists(config_path):
        config_manager.load()

    server_controller = ServerController(
        server_dir=server_dir,
        config_path=config_path,
        output_callback=_log_callback,
    )

    rcon = config.get("rcon", {})
    server_controller.set_rcon(rcon.get("password", ""), int(rcon.get("port", 8081)))

    mods_dir = os.path.join(server_dir, "Mods") if server_dir else ""
    worlds_dir = os.path.join(server_dir, "Data", "Worlds") if server_dir else ""
    mod_manager = ModManager(mods_dir)
    world_manager = WorldManager(worlds_dir)

    # 启动独立日志监控（支持外部启动的服务器也能看到日志）
    if server_dir:
        server_controller.start_log_watcher()

def apply_paths(server_dir: str, config_path: str, backup_dir: str = "", saves_dir: str = ""):
    """热更新路径配置，无需重启服务"""
    global app_config
    app_config.setdefault("server", {})
    app_config["server"].update(
        dir=server_dir, config_path=config_path,
        backup_dir=backup_dir, saves_dir=saves_dir,
    )
    if server_controller:
        server_controller.server_dir = server_dir
        server_controller.config_path = config_path
        # 同步 Rcon 密码
        if config_manager and config_manager.root is not None:
            pw  = config_manager.get_value("TelnetPassword")
            pt  = config_manager.get_value("TelnetPort")
            if pw:
                server_controller.set_rcon(pw, int(pt) if pt.isdigit() else 8081)
    if config_manager:
        config_manager.config_path = config_path
        if config_path and os.path.exists(config_path):
            config_manager.load()
    if mod_manager:
        mod_manager.mods_dir = os.path.join(server_dir, "Mods") if server_dir else ""
    if world_manager:
        world_manager.worlds_dir = os.path.join(server_dir, "Data", "Worlds") if server_dir else ""
